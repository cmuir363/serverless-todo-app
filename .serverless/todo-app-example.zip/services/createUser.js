const serverless = require('serverless-http');
const bodyParser = require('body-parser');
const express = require('express')
const app = express()
const AWS = require('aws-sdk');
const cryptoRandomString = require('crypto-random-string');

const TODO_APP_TABLE = process.env.TODO_APP_TABLE;
const TODO_APP_GSI_1 = process.env.TODO_APP_GSI_1;

const IS_OFFLINE = process.env.IS_OFFLINE;
let dynamoDb;
if (IS_OFFLINE === 'true') {
  dynamoDb = new AWS.DynamoDB.DocumentClient({
    region: 'localhost',
    endpoint: 'http://localhost:8000'
  })
  console.log(dynamoDb);
} else {
  dynamoDb = new AWS.DynamoDB.DocumentClient();
};

app.use(bodyParser.json({ strict: false }));

//validate email functions
function ValidateEmail(mail) {
 if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(mail))
  {
    return (true)
  }
    return (false)
}

// Create User endpoint
app.post('/users', function (req, res) {
  const { name, email } = req.body;
  console.log(req.body)
  console.log(name, email)
  if (typeof name !== 'string') {
    res.status(400).json({ error: '"name" must be a string' });
  } else if (typeof email !== 'string') {
    res.status(400).json({ error: '"email" must be a string' });
  } else if (ValidateEmail(email) === false) {
    res.status(400).json({ error: 'please enter a valid email' })
  }

  // assign a random userId value
  //const partitionKey = cryptoRandomString({length: 32});
  const partitionKey = 'hello'

  //assign timestamp for user creation
  //const sortKey = 'world';
  const sortKey = cryptoRandomString({length: 32});

  //create a canvas which will be this users first

  const params = {
    TableName: TODO_APP_TABLE,
    Item: {
      partitionKey: 'hello',
      sortKey: sortKey,
      name: name,
      data: email
    },
  };


  dynamoDb.put(params, (error) => {
    if (error) {
      console.log(error);
      res.status(400).json({ error: 'Could not create user' });
    }
    res.status(201).json({ partitionKey, sortKey, name, email });
  });
})

module.exports.handler = serverless(app);
