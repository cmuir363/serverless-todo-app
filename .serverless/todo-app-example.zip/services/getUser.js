const serverless = require('serverless-http');
const bodyParser = require('body-parser');
const express = require('express')
const app = express()
const AWS = require('aws-sdk');

const TODO_APP_TABLE = process.env.TODO_APP_TABLE;
const TODO_APP_GSI_1 = process.env.TODO_APP_GSI_1;

const IS_OFFLINE = process.env.IS_OFFLINE;
let dynamoDb;
if (IS_OFFLINE === 'true') {
  dynamoDb = new AWS.DynamoDB.DocumentClient({
    region: 'localhost',
    endpoint: 'http://localhost:8000'
  })
  console.log(dynamoDb);
} else {
  dynamoDb = new AWS.DynamoDB.DocumentClient();
};

app.use(bodyParser.json({ strict: false }));

// Get User endpoint
app.get('/users', function (req, res) {

// this section checks the request and create query parameters accordingly

  //check if rangeKey is provided if so use range key
  let params
  if (req.query.email) {
    params = {
      TableName: TODO_APP_TABLE,
      IndexName: TODO_APP_GSI_1,
      ExpressionAttributeNames: { "#da": "data"},
      KeyConditionExpression: "sortKey = :sKey and #da = :dKey",
      ExpressionAttributeValues: {
        ":dKey": req.query.email,
        ":sKey": "2057048ef27d25d8cb2bf78573b557ca"
      }
    }
  } else if (req.query.userSort) {
    params = {
      TableName: TODO_APP_TABLE,
      KeyConditionExpression: "partitionKey = :pKey and begins_with(sortKey, :sKey)",
      ExpressionAttributeValues: {
        ":pKey": req.query.userId,
        ":sKey": req.query.userSort
      }
    }
  } else {
    params = {
      TableName: TODO_APP_TABLE,
      KeyConditionExpression: "partitionKey = :pKey",
      ExpressionAttributeValues: {
        ":pKey": req.query.userId
      }
    }
  }


  dynamoDb.query(params, (error, result) => {
    if (error) {
      console.log(error);
      res.status(400).json({ error: 'Could not get user' });
    }
    if (result.Items) {
      res.status(200).json({ result });
    } else {
      res.status(404).json({ error: 'User Not Found'})
    }
  });
})

module.exports.handler = serverless(app);
